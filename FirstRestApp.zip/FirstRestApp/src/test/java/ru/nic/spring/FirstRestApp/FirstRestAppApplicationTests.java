package ru.nic.spring.FirstRestApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstRestAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
